import{r as e}from"./export-CnP27bmb.js";import{F as t,M as n,k as r}from"./index-CVtH8G1t.js";function i(e){return String(e??``).replaceAll(`&`,`&amp;`).replaceAll(`<`,`&lt;`).replaceAll(`>`,`&gt;`).replaceAll(`"`,`&quot;`)}function a(a,o){let s=Number(a.igstAmount)>0,c=a.items.map(e=>`<tr>
        <td>${i(e.itemName)}<div class="muted">${i(e.itemCode)}</div></td>
        <td class="right">${t(e.quantity)} ${e.unit}</td>
        <td class="right">${n(e.purchaseRate)}</td>
        <td class="right">${n(e.discount)}</td>
        <td class="right">${n(e.tax)}<div class="muted">${i(e.taxName)} ${Number(e.gstPercentage??0)}%</div></td>
        <td class="right">${n(e.totalAmount??0)}</td>
      </tr>`).join(``);e(`<div class="title-row">
      <div>
        <p class="brand">${i(o.name)}</p>
        <h1>Purchase invoice</h1>
        <p class="muted">${i(a.purchaseNumber)}${a.invoiceNumber?` · Supplier invoice ${i(a.invoiceNumber)}`:``}</p>
      </div>
      <div class="right">
        <p><strong>${i(a.branchName)}</strong></p>
        <p class="muted">${r(a.purchaseDate)}</p>
        <p class="muted">Status: ${i(a.status)}</p>
      </div>
    </div>
    <div class="grid">
      <div class="box"><strong>Supplier</strong><br/>${i(a.supplierName)}</div>
      <div class="box"><strong>Payment</strong><br/>Paid ${n(a.paidAmount)} · Balance ${n(a.balanceAmount)}</div>
    </div>
    <table>
      <thead><tr><th>Item</th><th class="right">Qty</th><th class="right">Rate</th><th class="right">Discount</th><th class="right">Tax</th><th class="right">Amount</th></tr></thead>
      <tbody>${c}</tbody>
    </table>
    <div class="totals">
      <div><span>Subtotal</span><span>${n(a.subtotal)}</span></div>
      <div><span>Discount</span><span>− ${n(a.discount)}</span></div>
      <div><span>Taxable value</span><span>${n(a.taxableAmount)}</span></div>
      ${s?`<div><span>IGST</span><span>${n(a.igstAmount)}</span></div>`:`<div><span>CGST</span><span>${n(a.cgstAmount)}</span></div>
             <div><span>SGST</span><span>${n(a.sgstAmount)}</span></div>`}
      <div><span>Total tax</span><span>${n(a.tax)}</span></div>
      <div class="grand"><span>Grand total</span><span>${n(a.grandTotal)}</span></div>
    </div>
    ${a.notes?`<p class="muted" style="margin-top:14px">Notes: ${i(a.notes)}</p>`:``}`,`Purchase ${a.purchaseNumber}`)}function o(a,o){let s=Number(a.igstAmount)>0,c=a.items.map(e=>`<tr>
        <td>${i(e.itemName)}<div class="muted">${t(e.quantity)} ${e.unit} × ${n(e.sellingRate)}</div></td>
        <td class="right">${n(e.totalAmount??0)}</td>
      </tr>`).join(``);e(`<div style="max-width:300px;margin:0 auto;font-family:'Courier New',monospace;font-size:11px">
      <div style="text-align:center;margin-bottom:10px">
        <p style="font-size:14px;font-weight:700;margin:0">${i(o.name)}</p>
        <p class="muted" style="margin:2px 0">${i(a.branchName)}</p>
        ${o.gstNumber?`<p class="muted" style="margin:2px 0">GSTIN ${i(o.gstNumber)}</p>`:``}
        <p class="muted" style="margin:2px 0">${r(a.salesDate)} · ${i(a.salesNumber)}</p>
      </div>
      <div style="border-top:1px dashed #9ca3af;border-bottom:1px dashed #9ca3af;padding:6px 0;margin-bottom:6px">
        <p style="margin:2px 0">Customer: ${i(a.customerName||`Walk-in`)}</p>
        ${a.customerMobile?`<p style="margin:2px 0">Mobile: ${i(a.customerMobile)}</p>`:``}
        ${a.customerState?`<p style="margin:2px 0">Place of supply: ${i(a.customerState)}</p>`:``}
      </div>
      <table style="margin:0;font-size:11px">
        <tbody>${c}</tbody>
      </table>
      <div style="border-top:1px dashed #9ca3af;margin-top:8px;padding-top:6px">
        <div style="display:flex;justify-content:space-between"><span>Subtotal</span><span>${n(a.subtotal)}</span></div>
        <div style="display:flex;justify-content:space-between"><span>Discount</span><span>− ${n(a.discount)}</span></div>
        <div style="display:flex;justify-content:space-between"><span>Taxable value</span><span>${n(a.taxableAmount)}</span></div>
        ${s?`<div style="display:flex;justify-content:space-between"><span>IGST</span><span>${n(a.igstAmount)}</span></div>`:`<div style="display:flex;justify-content:space-between"><span>CGST</span><span>${n(a.cgstAmount)}</span></div>
               <div style="display:flex;justify-content:space-between"><span>SGST</span><span>${n(a.sgstAmount)}</span></div>`}
        <div style="display:flex;justify-content:space-between"><span>Total tax</span><span>${n(a.tax)}</span></div>
        <div style="display:flex;justify-content:space-between;font-weight:700;font-size:13px;margin-top:4px"><span>Total</span><span>${n(a.grandTotal)}</span></div>
        <div style="display:flex;justify-content:space-between;margin-top:4px"><span>Paid (${i(a.paymentMethod)})</span><span>${n(a.paidAmount)}</span></div>
        ${Number(a.balanceAmount)>0?`<div style="display:flex;justify-content:space-between"><span>Balance</span><span>${n(a.balanceAmount)}</span></div>`:``}
      </div>
      <p style="text-align:center;margin-top:14px" class="muted">Thank you for your business!</p>
      <p style="text-align:center;margin-top:4px" class="muted">Item Management System</p>
    </div>`,`Receipt ${a.salesNumber}`)}export{o as n,a as t};