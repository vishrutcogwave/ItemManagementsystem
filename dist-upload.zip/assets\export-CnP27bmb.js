const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/jspdf.es.min-rEoh7WXn.js","assets/rolldown-runtime-XKyaHtl9.js","assets/index-CVtH8G1t.js","assets/index-mbYAF6VD.css"])))=>i.map(i=>d[i]);
import{t as e}from"./index-CVtH8G1t.js";function t(e){return e.replace(/[\\/:*?"<>|]+/g,`-`).trim()}async function n(n,r,i,a){let o=await e(()=>import(`./xlsx-DR4W_luh.js`),[]),s=a.map(e=>{let t={};for(let n of i)t[n.header]=n.value(e);return t}),c=o.utils.json_to_sheet(s,{header:i.map(e=>e.header)});c[`!cols`]=i.map(e=>({wch:e.width??Math.max(12,e.header.length+4)}));let l=o.utils.book_new();o.utils.book_append_sheet(l,c,r.slice(0,31)),o.writeFile(l,`${t(n)}.xlsx`)}async function r({title:n,filename:r,columns:i,rows:a,subtitle:o,orientation:s=`landscape`,summary:c=[]}){let[{default:l},{default:u}]=await Promise.all([e(()=>import(`./jspdf.es.min-rEoh7WXn.js`).then(e=>e.t),__vite__mapDeps([0,1,2,3])),e(()=>import(`./jspdf.plugin.autotable-2eOJeXl-.js`),[])]),d=new l({orientation:s,unit:`pt`,format:`a4`}),f=d.internal.pageSize.getWidth();d.setFontSize(16),d.setFont(`helvetica`,`bold`),d.text(n,40,44),d.setFontSize(9),d.setFont(`helvetica`,`normal`),d.setTextColor(110),o&&d.text(o,40,60);let p=`Generated ${new Date().toLocaleString(`en-IN`)}`;d.text(p,f-40,60,{align:`right`});let m=76;c.length>0&&(d.setTextColor(60),d.setFontSize(10),d.text(c.join(`    |    `),40,m),m+=16),u(d,{startY:m,head:[i.map(e=>e.header)],body:a.map(e=>i.map(t=>String(t.value(e)))),styles:{fontSize:8,cellPadding:5,textColor:[45,55,72]},headStyles:{fillColor:[234,88,12],textColor:255,fontStyle:`bold`},alternateRowStyles:{fillColor:[250,250,252]},margin:{left:40,right:40}}),d.setFontSize(8),d.setTextColor(140);let h=d.getNumberOfPages();for(let e=1;e<=h;e+=1)d.setPage(e),d.text(`Item Management System · Page ${e} of ${h}`,f/2,d.internal.pageSize.getHeight()-20,{align:`center`});d.save(`${t(r)}.pdf`)}function i(e){return String(e??``).replaceAll(`&`,`&amp;`).replaceAll(`<`,`&lt;`).replaceAll(`>`,`&gt;`)}function a({title:e,subtitle:t,columns:n,rows:r,summary:a=[]}){let s=n.map(e=>`<th>${i(e.header)}</th>`).join(``),c=r.map(e=>`<tr>${n.map(t=>`<td>${i(t.value(e))}</td>`).join(``)}</tr>`).join(``);o(`<div class="title-row">
      <div><p class="brand">Item Management System</p><h1>${i(e)}</h1>${t?`<p class="muted">${i(t)}</p>`:``}</div>
      <p class="muted">${new Date().toLocaleString(`en-IN`)}</p>
    </div>
    ${a.length>0?`<p class="muted">${a.map(i).join(` &nbsp;|&nbsp; `)}</p>`:``}
    <table><thead><tr>${s}</tr></thead><tbody>${c}</tbody></table>
    <p class="muted" style="margin-top:14px">${r.length} rows</p>`,e)}function o(e,t){let n=document.createElement(`iframe`);n.style.position=`fixed`,n.style.right=`0`,n.style.bottom=`0`,n.style.width=`0`,n.style.height=`0`,n.style.border=`0`,document.body.appendChild(n);let r=n.contentWindow?.document;r&&(r.open(),r.write(`<!doctype html><html><head><title>${t}</title><style>
    * { box-sizing: border-box; }
    body { margin: 0; padding: 24px; font-family: 'Segoe UI', Arial, sans-serif; color: #1f2937; }
    h1, h2, h3 { margin: 0 0 6px; }
    table { width: 100%; border-collapse: collapse; margin-top: 16px; font-size: 12px; }
    th { background: #f3f4f6; text-align: left; padding: 8px; border-bottom: 1px solid #d1d5db; }
    td { padding: 7px 8px; border-bottom: 1px solid #e5e7eb; }
    .muted { color: #6b7280; }
    .right { text-align: right; }
    .title-row { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 16px; }
    .brand { color: #ea580c; font-weight: 700; letter-spacing: 0.06em; text-transform: uppercase; font-size: 11px; }
    .grid { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; font-size: 12px; }
    .box { border: 1px solid #e5e7eb; border-radius: 8px; padding: 10px 12px; }
    .totals { margin-top: 14px; margin-left: auto; width: 260px; font-size: 12px; }
    .totals div { display: flex; justify-content: space-between; padding: 3px 0; }
    .totals .grand { border-top: 1px solid #d1d5db; margin-top: 4px; padding-top: 6px; font-weight: 700; font-size: 14px; }
    @media print { body { padding: 0; } }
  </style></head><body>${e}</body></html>`),r.close(),n.contentWindow?.focus(),setTimeout(()=>{n.contentWindow?.print(),setTimeout(()=>n.remove(),1e3)},250))}export{a as i,r as n,o as r,n as t};